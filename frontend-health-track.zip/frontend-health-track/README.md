# Fontend do projeto Health Track

Esse projeto responsivo foi desenvolvido utilizando as tecnologias:

- HTML 5
- CSS 3
- JavaScript

# Login

![picture](prints/login.PNG)

![picture](prints/login-responsivo.PNG)

# Criar uma conta

![picture](prints/registrar.PNG)

![picture](prints/register-responsive.PNG)

# Dashboard 

![picture](prints/dashboard.PNG)

![picture](prints/dashboard-nav-open.PNG)